<?php
session_start();

if (isset($_POST['submit'])) {
    $_SESSION['mySession'] = $_POST['value'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Session Example</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-image: url('bg.jpg'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"] {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid #ddd;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 12px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .session-value {
            margin-top: 20px;
            font-size: 18px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Session Example</h2>
        <form method="post" action="">
            <label for="value">Enter Value:</label>
            <input type="text" id="value" name="value">
            <input type="submit" name="submit" value="Submit">
        </form>
        <div class="session-value">
            <?php
            if (isset($_SESSION['mySession'])) {
                echo "Session Value: " . htmlspecialchars($_SESSION['mySession']);
            }
            ?>
        </div>
    </div>
</body>
</html>

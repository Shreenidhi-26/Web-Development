<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Example</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-image: url('bg.jpg'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            text-align: center;
            margin: 0;
            padding: 50px;
            height: 100vh;
            box-sizing: border-box;
            animation: fadeIn 1s ease-in-out; 
        }
        h2 {
            color: #333;
        }
        p {
            color: #007BFF;
            font-weight: bold;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <h2>MySQL Example</h2>
    <?php
    // Enable error reporting
    error_reporting(E_ALL);
    ini_set('display_errors', '1');

    // Connect to MySQL database
    $servername = "localhost";
    $username = "root";
    $password = "123456";
    $dbname = "example_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("<p>Connection failed: " . $conn->connect_error . "</p>");
    }

    // Create a table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(30) NOT NULL,
        email VARCHAR(50) NOT NULL
    )";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Table created successfully</p>";
    } else {
        echo "<p>Error creating table: " . $conn->error . "</p>";
    }

    // Insert data
    $sql = "INSERT INTO users (username, email) VALUES ('Nidhi', 'nidhi.kulkarni@example.com')";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Data inserted successfully</p>";
    } else {
        echo "<p>Error inserting data: " . $conn->error . "</p>";
    }

    // Retrieve and display data
    $sql = "SELECT id, username, email FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<p>ID: " . $row["id"]. " - Name: " . $row["username"]. " - Email: " . $row["email"]. "</p>";
        }
    } else {
        echo "<p>0 results</p>";
    }

    // Close the connection
    $conn->close();
    ?>
</body>
</html>

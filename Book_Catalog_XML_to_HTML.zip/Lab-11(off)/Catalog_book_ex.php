<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Catalog Viewer</title>
    <style>
    body {
    font-family: 'Arial', sans-serif;
    margin: 20px;
    background-color: rgba(0, 0, 0, 0.5); 
    background-image: url('catalog.jpg');
    background-size: cover;
    background-position: center;
    transition: background-image 0.5s ease;
}

h1 {
    text-align: center;
    color: #fff; 
    background-color: rgba(0, 0, 0, 0.8); 
    padding: 20px;
    margin: 0;
}

#book-list {
    margin-top: 20px;
    overflow: hidden;
    
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    box-shadow: 0 4px 8px rgba(255, 255, 255, 0.1); 
    background-color: rgba(0, 0, 0, 0.9);
    opacity: 0.9;
    transition: opacity 0.5s ease;
}

th, td {
    border: 1px solid #fff; 
    padding: 12px;
    text-align: left;
    color: #fff; 
}

th {
    background-color: rgba(0, 0, 0, 0.8); 
    color: #fff; 
}

tr {
    transition: background-color 0.3s ease;
}

tr:hover {
    background-color: #f2f2f2;
    color: #000000; 
    
}

    </style>
</head>

<body>
    <h1>Book Catalog</h1>
    <div id="book-list">
        <?php
        // Function to display the catalog
        function displayCatalog($xml)
        {
            $books = $xml->getElementsByTagName('book');

            echo '<table>';
            echo '<tr>';
            echo '<th>Title</th>';
            echo '<th>Author</th>';
            echo '<th>Genre</th>';
            echo '<th>Publication Year</th>';
            echo '<th>Publisher</th>';
            echo '<th>Language</th>';
            echo '<th>ISBN</th>';
            echo '</tr>';

            foreach ($books as $book) {
                $title = $book->getElementsByTagName('title')[0]->nodeValue;
                $author = $book->getElementsByTagName('author')[0]->nodeValue;
                $genre = $book->getElementsByTagName('genre')[0]->nodeValue;
                $publicationYear = $book->getElementsByTagName('publicationYear')[0]->nodeValue;
                $publisher = $book->getElementsByTagName('publisher')[0]->nodeValue;
                $language = $book->getElementsByTagName('language')[0]->nodeValue;
                $isbn = $book->getElementsByTagName('isbn')[0]->nodeValue;

                echo '<tr>';
                echo '<td>' . $title . '</td>';
                echo '<td>' . $author . '</td>';
                echo '<td>' . $genre . '</td>';
                echo '<td>' . $publicationYear . '</td>';
                echo '<td>' . $publisher . '</td>';
                echo '<td>' . $language . '</td>';
                echo '<td>' . $isbn . '</td>';
                echo '</tr>';
            }

            echo '</table>';
        }

        // Load and parse the XML file
        $xmlPath = 'book_catalog_ex.xml';
        $xml = new DOMDocument();
        $xml->load($xmlPath);

        // Display the catalog
        displayCatalog($xml);
        ?>
    </div>
</body>

</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Display - Page 2</title>
    <style>
        body {
            background: url('img2.jpeg') center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        h1 {
            color: #333;
        }

        p {
            color: #333; 
            margin-bottom: 8px;
        }

        strong {
            font-weight: bold;
        }

        div {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <br/>
    <h1>Received Student Information</h1>
    <br/>

    <div>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            $rollNo = $_GET["rollNo"];
            $name = $_GET["name"];
            $class = $_GET["class"];
            $section = $_GET["section"];
            $email = $_GET["email"];
            $phone = $_GET["phone"];
            $city = $_GET["city"];

            echo "<p><strong>Roll No:</strong> $rollNo</p>";
            echo "<p><strong>Name:</strong> $name</p>";
            echo "<p><strong>Class:</strong> $class</p>";
            echo "<p><strong>Section:</strong> $section</p>";
            echo "<p><strong>Email:</strong> $email</p>";
            echo "<p><strong>Phone Number:</strong> $phone</p>";
            echo "<p><strong>City:</strong> $city</p>";
        }
        ?>
    </div>
</body>
</html>
